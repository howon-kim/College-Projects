Neural network xml file is saved here
