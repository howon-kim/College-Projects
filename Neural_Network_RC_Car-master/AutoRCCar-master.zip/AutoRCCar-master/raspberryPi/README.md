Client programs on Rapsberry Pi did not stray too far from these two great tutorials: 

[PiCamera Documentation - Advanced Recipes](https://picamera.readthedocs.org/en/release-1.10/recipes2.html)

[Ultrasonic Distance Measurement Using Python – Part 2](http://www.raspberrypi-spy.co.uk/2013/01/ultrasonic-distance-measurement-using-python-part-2/)
