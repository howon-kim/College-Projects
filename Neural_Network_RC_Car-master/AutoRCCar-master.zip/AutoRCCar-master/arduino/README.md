Inspired by this aiticle: [Drive a Lamborghini With Your Keyboard](http://thelivingpearl.com/2013/01/04/drive-a-lamborghini-with-your-keyboard/)
